from django.apps import AppConfig


class FormularConfig(AppConfig):
    name = 'formular'
